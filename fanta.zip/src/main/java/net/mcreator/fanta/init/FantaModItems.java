
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.fanta.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.mcreator.fanta.item.PurefantaItem;
import net.mcreator.fanta.item.FantadimensionItem;
import net.mcreator.fanta.item.FantaItem;
import net.mcreator.fanta.item.EmptycanItem;
import net.mcreator.fanta.FantaMod;

public class FantaModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, FantaMod.MODID);
	public static final RegistryObject<Item> EMPTYCAN = REGISTRY.register("emptycan", () -> new EmptycanItem());
	public static final RegistryObject<Item> FANTA = REGISTRY.register("fanta", () -> new FantaItem());
	public static final RegistryObject<Item> PUREFANTA_BUCKET = REGISTRY.register("purefanta_bucket", () -> new PurefantaItem());
	public static final RegistryObject<Item> FANTADIMENSION = REGISTRY.register("fantadimension", () -> new FantadimensionItem());
	public static final RegistryObject<Item> SOLIDFANTA = block(FantaModBlocks.SOLIDFANTA, CreativeModeTab.TAB_BUILDING_BLOCKS);

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}
