
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.fanta.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.fanta.block.SolidfantaBlock;
import net.mcreator.fanta.block.PurefantaBlock;
import net.mcreator.fanta.block.FantadimensionPortalBlock;
import net.mcreator.fanta.FantaMod;

public class FantaModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, FantaMod.MODID);
	public static final RegistryObject<Block> PUREFANTA = REGISTRY.register("purefanta", () -> new PurefantaBlock());
	public static final RegistryObject<Block> FANTADIMENSION_PORTAL = REGISTRY.register("fantadimension_portal",
			() -> new FantadimensionPortalBlock());
	public static final RegistryObject<Block> SOLIDFANTA = REGISTRY.register("solidfanta", () -> new SolidfantaBlock());
}
